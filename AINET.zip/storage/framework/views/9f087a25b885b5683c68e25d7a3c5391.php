<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <!--<li class="nav-item d-none d-sm-inline-block">
        <a href="index3.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>-->
    </ul>

    <!-- SEARCH FORM -->
    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Messages Dropdown Menu -->
        
        <!-- Notifications Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                
                <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" width="30px" height="30px"
                    class="img-circle elevation-2" alt="User Image">

                
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('admin.profile.edit')); ?>" class="dropdown-item">
                    <i class="fas fa-envelope mr-2"></i> Profile
                    
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('admin.user.changePassword')); ?>" class="dropdown-item">
                    <i class="fas fa-users mr-2"></i> Change Password
                    
                </a>
                   <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
                    <i class="fas fa-sign-out-alt"></i> Logout
                    
                </a>

                
                
            </div>
        </li>
        
    </ul>
</nav>
<!-- /.navbar -->
<?php /**PATH D:\AINET\resources\views/admin/layouts/navbar.blade.php ENDPATH**/ ?>