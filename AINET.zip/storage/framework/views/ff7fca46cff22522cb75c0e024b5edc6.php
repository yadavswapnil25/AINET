<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- include header -->
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="hold-transition sidebar-mini layout-fixed">    
        <div class="wrapper">
            <!-- include navbar -->
            <?php echo $__env->make('admin.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <!-- include sidebar -->
            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <!-- content -->
            <div class="content-wrapper">
                
                <?php echo $__env->yieldContent('content'); ?>
            </div>  
            
            <footer class="main-footer">
                <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/')); ?>">AINET</a>.</strong>
                All rights reserved.
            </footer>
            
            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
              <!-- Control sidebar content goes here -->
            </aside>
        </div>
        <?php echo $__env->make('admin.layouts.footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('pagejs'); ?>
        
    </body>
</html>
    <?php /**PATH D:\AINET\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>